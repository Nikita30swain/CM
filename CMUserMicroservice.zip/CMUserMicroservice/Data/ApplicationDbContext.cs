﻿using Microsoft.EntityFrameworkCore;
using System.Net.NetworkInformation;
using System.Collections.Generic;
using System.Reflection.Emit;
using CMUserMicroservice;

namespace CMUserMicroservice.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {



        }

    }
}



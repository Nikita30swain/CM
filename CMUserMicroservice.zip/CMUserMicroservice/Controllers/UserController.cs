﻿using CMUserMicroservice.RegisterViewModel;
using CMUserMicroservice.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Security.Claims;

namespace CMUserMicroservice.Controllers
{
	
	[ApiController]
	[Route("api/v1.0/users/")]
	public class UserController : ControllerBase
	{
		private readonly IUserService _userService;
		


		public UserController(IUserService userService)
		{
			_userService = userService;
			
		}

		

		

		[HttpPost("register")]
		public async Task<IActionResult> Register([FromBody] UserRegistrationModel model)
		{
			if (!ModelState.IsValid)
			{
				return BadRequest(ModelState);
			}

			var registrationResult = await _userService.RegisterUserAsync(model);

			if (registrationResult == "Registration successful")
			{
				return Ok(registrationResult);
			}
			else if (registrationResult == "User details already exist. Please login.")
			{
				return Conflict(registrationResult);
			}
			else
			{
				return BadRequest(registrationResult);
			}
		}

		[HttpGet("login/{email}/{password}")]
		public IActionResult Login(string email, string password)
		{
			var user = _userService.Login(email, password);

			if (user == null)
			{
				return NotFound("Details not found. Please register");
			}
			else
			{

				var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("this is my  custom Secret Key for authentication"));
				var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
				var tokeOptions = new JwtSecurityToken(
					issuer: "http://localhost:61605",
					audience: "http://localhost:61605",
					claims: new List<Claim>(),
					expires: DateTime.Now.AddMinutes(5),
					signingCredentials: signinCredentials
				);
				var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);

				return Ok(new {Token = tokenString, user });
			}


		}

	}

			
}

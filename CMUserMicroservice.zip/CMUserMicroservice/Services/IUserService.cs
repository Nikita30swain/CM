﻿using CMUserMicroservice.RegisterViewModel;
using CMUserMicroservice.Controllers;

namespace CMUserMicroservice.Services
{
    public interface IUserService
    {
		Task<string> RegisterUserAsync(UserRegistrationModel model);
		//Task<string> LoginAsync(string email, string password);
		User Login(string email, string password);

	}
}
﻿using CMUserMicroservice.Repository;
using System.Threading.Tasks;
using CMUserMicroservice.RegisterViewModel;
using CMUserMicroservice.Services;
using CMUserMicroservice.Controllers;

namespace CMUserMicroservice.Services
{

	// UserService.cs
	public class UserService : IUserService

	{
		private readonly IUserRepository _userRepository;


		public UserService(IUserRepository userRepository)
		{
			_userRepository = userRepository;
			
		}

		public async Task<string> RegisterUserAsync(UserRegistrationModel model)
		{
			// Check if the user already exists
			var existingUser = await _userRepository.GetUserByEmailAsync(model.Email);
			if (existingUser != null)
			{
				return "User details already exist. Please login.";
			}

			// Hash the password (you should implement password hashing here)
			
			// Create a User entity
			var newUser = new User
			{
				Email = model.Email,
				FullName = model.FullName,
				Password = model.Password
			};

			// Save the user to the database
			await _userRepository.CreateUserAsync(newUser);

			return "Registration successful";
		}
		/*public async Task<string> LoginAsync(string email, string password)
		{
			// Implement login logic here
			// Verify the email and password against the database
			// Return a message indicating success or failure

			// Example (replace with actual login logic):
			var user = await _userRepository.GetUserByEmailAsync(email);
			if (user != null)
			{
				return "Login successful";
			}
			else
			{
				return "Invalid email or password";
			}
		}*/

		public User Login(string email, string password)
		{
			return _userRepository.GetUserByEmailAndPassword(email, password);
		}

	}
}

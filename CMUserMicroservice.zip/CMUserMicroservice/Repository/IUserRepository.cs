﻿using CMUserMicroservice.Repository;
using CMUserMicroservice.Services;
using CMUserMicroservice.Controllers;
namespace CMUserMicroservice.Repository
{
	public interface IUserRepository
	{
		Task<User> GetUserByEmailAsync(string email);
		Task CreateUserAsync(User user);

		User GetUserByEmailAndPassword(string email, string password);
	}
}
﻿using System.Threading.Tasks;
using CMUserMicroservice.Data;
using Microsoft.EntityFrameworkCore;

namespace CMUserMicroservice.Repository
{

    public class UserRepository : IUserRepository
	{
		private ApplicationDbContext _context;

		public UserRepository(ApplicationDbContext context)
		{
			_context = context;
		}

		public async Task<User> GetUserByEmailAsync(string email)
		{
			return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
		}

		public async Task CreateUserAsync(User user)
		{
			_context.Users.Add(user);
			await _context.SaveChangesAsync();
		}
		public User GetUserByEmailAndPassword(string email, string password)
		{
			return _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
		}
	}
}
